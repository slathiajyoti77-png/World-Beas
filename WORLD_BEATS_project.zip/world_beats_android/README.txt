WORLD BEATS — Android project with automatic cloud APK build

Features:
- Search the Apple iTunes public catalog for songs and artists.
- Play available 30-second previews supplied by the catalog.
- Save favourites on this device and browse music categories.
- Internet is required for search and previews.

Music licensing note: this starter app uses preview URLs returned by the public iTunes Search API. It does not provide every commercial full-length track; those require licences.

BUILD THE APK USING ONLY YOUR PHONE (GitHub Actions)
1. Download and extract this ZIP on your phone.
2. In GitHub, create a new repository named world-beats. Choose Public or Private, and create it.
3. Open the new repository, tap Add file > Upload files.
4. Upload the CONTENTS of the extracted world_beats_android folder, including the hidden .github folder and its workflows/build-apk.yml file. Do not upload only the ZIP file. If your phone's file picker hides .github, use GitHub's web editor to create .github/workflows/build-apk.yml and paste the workflow from this project's workflow file.
5. Commit the upload to the main branch.
6. Open the repository's Actions tab. If GitHub asks, enable Actions.
7. Open "Build World Beats APK" and wait for the run to finish successfully.
8. Open the completed run, scroll to Artifacts, and download "world-beats-apk". Extract that downloaded ZIP; it contains app-debug.apk.
9. Tap app-debug.apk on your phone to install. Android may ask you to allow installs from your browser or file manager.

If Actions does not start automatically, open Actions > Build World Beats APK > Run workflow.

The APK built by GitHub Actions is a debug APK for personal testing, not a Play Store release. Keep your repository private if you do not want to publish your source code.
